let chart = null;
let tableData = [];

// Mise à jour dynamique du label du curseur
document.getElementById('N_etages').addEventListener('input', function() {
    document.getElementById('etages-value').textContent = this.value;
});

async function calculate() {
    const errorDiv = document.getElementById('error');
    errorDiv.classList.remove('show');
    
    try {
        const G_prime = parseFloat(document.getElementById('G_prime').value);
        const m = parseFloat(document.getElementById('m').value);
        const L = parseFloat(document.getElementById('L').value);
        const x0 = parseFloat(document.getElementById('x0').value);
        const N_etages = parseInt(document.getElementById('N_etages').value);

        // Validation
        if (isNaN(G_prime) || isNaN(m) || isNaN(L) || isNaN(x0)) {
            throw new Error('Tous les paramètres doivent être des nombres valides');
        }

        document.getElementById('loading').style.display = 'block';

        const response = await fetch('/calculate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                G_prime, m, L, x0, N_etages
            })
        });

        if (!response.ok) {
            throw new Error('Erreur lors du calcul');
        }

        const data = await response.json();
        displayResults(data);

    } catch (error) {
        errorDiv.textContent = '❌ Erreur: ' + error.message;
        errorDiv.classList.add('show');
    } finally {
        document.getElementById('loading').style.display = 'none';
    }
}

function displayResults(data) {
    // Afficher le panneau des résultats
    document.getElementById('results').classList.add('active');
    document.getElementById('table-panel').style.display = 'block';
    document.getElementById('chart-panel').style.display = 'block';

    // Remplir les résultats
    document.getElementById('S-value').textContent = data.S.toFixed(4);
    document.getElementById('exec-time').textContent = data.execution_time.toFixed(6) + ' s';
    document.getElementById('memory').textContent = data.memory_used.toFixed(6) + ' Mo';
    document.getElementById('x-entrant-min').textContent = data.stats.x_entrant_min.toFixed(6);
    document.getElementById('x-sortant-min').textContent = data.stats.x_sortant_min.toFixed(6);
    document.getElementById('mean-diff').textContent = data.stats.mean_diff.toFixed(6);

    // Remplir le tableau
    const tableBody = document.getElementById('tableBody');
    tableBody.innerHTML = '';
    tableData = [];
    
    data.table.forEach((row, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row['Étage']}</td>
            <td>${row['x_entrant'].toFixed(6)}</td>
            <td>${row['x_sortant'].toFixed(6)}</td>
        `;
        tableBody.appendChild(tr);
        tableData.push(row);
    });

    // Mettre à jour le graphique
    updateChart(data.etages, data.x_entrant, data.x_sortant);
}

function updateChart(etages, x_entrant, x_sortant) {
    const ctx = document.getElementById('myChart').getContext('2d');
    
    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: etages,
            datasets: [
                {
                    label: 'x_entrant',
                    data: x_entrant,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 6,
                    pointBackgroundColor: '#667eea',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 8
                },
                {
                    label: 'x_sortant',
                    data: x_sortant,
                    borderColor: '#764ba2',
                    backgroundColor: 'rgba(118, 75, 162, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 6,
                    pointBackgroundColor: '#764ba2',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 8
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        font: { size: 12, weight: 'bold' },
                        padding: 15
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Concentration x'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Nombre d\'étages'
                    }
                }
            }
        }
    });
}

function downloadCSV() {
    if (tableData.length === 0) return;

    let csv = 'Étage,x_entrant,x_sortant\n';
    tableData.forEach(row => {
        csv += `${row['Étage']},${row['x_entrant']},${row['x_sortant']}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'concentrations.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
}

// Calcul automatique au chargement
window.addEventListener('load', function() {
    calculate();
});
